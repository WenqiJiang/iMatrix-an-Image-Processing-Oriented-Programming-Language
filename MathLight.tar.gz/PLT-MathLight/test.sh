./mathlight.native tests/$1 > test.ll
llc -relocation-model=pic test.ll > test.s
cc -o test.exe test.s matrices.o
./test.exe