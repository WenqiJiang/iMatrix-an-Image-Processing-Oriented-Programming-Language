# VSCOde
Make art, not war.

A language created to spread love and art.
Note to anyone referrencing this: Please read our final thoughts section before your take any inspiration from us (we learned this the hard way).

## TO RUN
It is recommended to run VSCOde on VirtualBox. Simply follow the VirtualBox Setup Instructions to get started. With VirtualBox set up, install OpenCV and run the program.
### Set up Homebrew 
To ease the installation process, download Homebrew package manager.

`/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"`

Also install Homebrew Cask, a Homebrew extension to speed up OS X installations. 
`brew tap caskroom/cask`

### Set up VirtualBox
To quickly get started, install VirtualBox.

`brew cask install virtualbox`

Then, download Numel, a Virtual Image with LLVM made by the John Hui.

`wget http://www.cs.columbia.edu/~sedwards/classes/2018/4115-fall/numel.ova`

Username/Password: al / plt

### Install OpenCV
OpenCV is a C++ library, used for image manipulation, image loading, and image saving.

`sudo apt-get install opencv-data`

Also install the development files for opencv.

`sudo apt-get install libopencv-dev`

### Install Clang and LLVM 
Clang and LLVM will compile and link in OpenCV.

`sudo apt install clang-4.0`

`sudo apt install llvm-5.0`

### Running VSCOde
To run test code ${basename}.vsc run the following.

`make clean`

`make`

`./link.sh [BASENAME]`

To instead run the pre-written test codes, run the following.

./testall.sh
