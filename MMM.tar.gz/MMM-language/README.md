# MMM-language
Environment Setup
MMM is developed on Ocaml and LLVM. Please have Ocaml and LLVM installed. Besides, LLVM uses
openCV library through C++ program.

1 Install Homebrew
Homebrew is a free and open-source software package management system that simplifies the installation
of software on Apple's macOS operating system.
$ /usr/bin/ruby -e "$(curl -fsSL
https://raw.githubusercontent.com/Homebrew/install/master/install)"

2 Install openCV
OpenCV (Open source computer vision) is a library of programming functions mainly aimed at real-time
computer vision. We will use its function to read, write, and convolve images.
$brew install opencv

3 Install pkg-config
pkg-config is a helper tool used when compiling applications and libraries. It helps you insert the correct
compiler options on the command line rather than hard-coding values.
$brew install pkg-config

4 Install glog
Glog is a logging library for C++.
$brew install glog